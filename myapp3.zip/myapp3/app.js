const express=require('express');
const app=express();
app.set('view engine','ejs');


app.get("/contact",function(req,res){
	res.render('Contact')
})

app.get("/regs",function(req,res){
	res.render('Regs')
})


app.get("/login",function(req,res){
	res.render('Login')
})



app.get("/about",function(req,res){
	res.render('About')
})


app.get("/",function(req,res){
	res.render('Home')
})



app.listen(4500);




